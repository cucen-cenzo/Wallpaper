package com.moonwall.live

import android.graphics.*
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.service.wallpaper.WallpaperService
import android.view.MotionEvent
import android.view.SurfaceHolder
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.pow

class MoonWallpaperService : WallpaperService() {

    override fun onCreateEngine(): Engine = MoonEngine()

    private inner class MoonEngine : Engine() {

        // Moon position inside the photo (pixels of the original image)
        private val moonX = 535f
        private val moonY = 305f
        private val moonR = 185f

        private val pulseMs = 2200L
        private val swipeDistance = 140f   // px of finger travel per pulse

        private val handler = Handler(Looper.getMainLooper())
        private val frameRunner = Runnable { drawFrame() }
        private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            xfermode = PorterDuffXfermode(PorterDuff.Mode.SCREEN)
        }

        private var bitmap: Bitmap? = null
        private var scale = 1f
        private var dx = 0f
        private var dy = 0f
        private var visible = false

        private val pulses = ArrayList<Long>()
        private var glow = 0f
        private var lastFrame = 0L
        private var lastPulse = 0L

        private var lastX = 0f
        private var lastY = 0f
        private var travelled = 0f
        private var lastOffset = -1f

        override fun onCreate(holder: SurfaceHolder) {
            super.onCreate(holder)
            setTouchEventsEnabled(true)
            val opts = BitmapFactory.Options().apply { inScaled = false }
            bitmap = BitmapFactory.decodeResource(resources, R.drawable.moon_bg, opts)
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            val bmp = bitmap ?: return
            scale = max(width / bmp.width.toFloat(), height / bmp.height.toFloat())
            dx = (width - bmp.width * scale) / 2f
            dy = (height - bmp.height * scale) / 2f
            drawFrame()
        }

        override fun onVisibilityChanged(isVisible: Boolean) {
            visible = isVisible
            if (isVisible) drawFrame() else handler.removeCallbacks(frameRunner)
        }

        override fun onDestroy() {
            super.onDestroy()
            handler.removeCallbacks(frameRunner)
            bitmap?.recycle()
            bitmap = null
        }

        // Swiping between home screens (launcher passes the scroll offset)
        override fun onOffsetsChanged(
            xOffset: Float, yOffset: Float, xStep: Float, yStep: Float, xPixels: Int, yPixels: Int
        ) {
            if (lastOffset >= 0f && abs(xOffset - lastOffset) > 0.01f) triggerPulse(throttle = true)
            lastOffset = xOffset
        }

        // Swiping directly on the wallpaper (lock screen / launchers that forward touches)
        override fun onTouchEvent(event: MotionEvent) {
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    lastX = event.x; lastY = event.y; travelled = 0f
                }
                MotionEvent.ACTION_MOVE -> {
                    travelled += hypot(event.x - lastX, event.y - lastY)
                    lastX = event.x; lastY = event.y
                    if (travelled >= swipeDistance) {
                        travelled = 0f
                        triggerPulse(throttle = false)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (travelled > 40f) triggerPulse(throttle = false)
                    travelled = 0f
                }
            }
        }

        private fun triggerPulse(throttle: Boolean) {
            val now = SystemClock.uptimeMillis()
            if (throttle && now - lastPulse < 300) return
            lastPulse = now
            if (pulses.size >= 6) pulses.removeAt(0)
            pulses.add(now)
            glow = 1f
            if (visible) drawFrame()
        }

        private fun drawFrame() {
            handler.removeCallbacks(frameRunner)
            val now = SystemClock.uptimeMillis()
            val dt = if (lastFrame == 0L) 16L else (now - lastFrame).coerceAtMost(50L)
            lastFrame = now
            glow = max(0f, glow - dt / 1600f)
            pulses.removeAll { now - it > pulseMs }

            val holder = surfaceHolder
            var canvas: Canvas? = null
            try {
                canvas = holder.lockCanvas()
                if (canvas != null) render(canvas, now)
            } finally {
                if (canvas != null) {
                    try { holder.unlockCanvasAndPost(canvas) } catch (_: IllegalArgumentException) {}
                }
            }

            if (visible && (pulses.isNotEmpty() || glow > 0f)) {
                handler.postDelayed(frameRunner, 16)
            } else {
                lastFrame = 0L   // idle: no more frames, saves battery
            }
        }

        private fun render(canvas: Canvas, now: Long) {
            canvas.drawColor(Color.BLACK)
            val bmp = bitmap ?: return
            canvas.save()
            canvas.translate(dx, dy)
            canvas.scale(scale, scale)
            canvas.drawBitmap(bmp, 0f, 0f, bgPaint)
            canvas.restore()

            val cx = dx + moonX * scale
            val cy = dy + moonY * scale
            val r = moonR * scale

            // Soft halo that flares on swipe and fades
            if (glow > 0f) {
                val gr = r * 2.4f
                glowPaint.shader = RadialGradient(
                    cx, cy, gr,
                    intArrayOf(argb(glow * 0.55f), 0x00FF8C28),
                    floatArrayOf(0.35f, 1f),
                    Shader.TileMode.CLAMP
                )
                canvas.drawCircle(cx, cy, gr, glowPaint)
            }

            // Expanding rings of light
            for (start in pulses) {
                val t = ((now - start) / pulseMs.toFloat()).coerceIn(0f, 1f)
                val eased = 1f - (1f - t) * (1f - t)
                val radius = r * (1f + eased * 5.5f)
                val alpha = (1f - t).pow(1.5f) * 0.6f
                glowPaint.shader = RadialGradient(
                    cx, cy, radius,
                    intArrayOf(0x00FF8C28, argb(alpha), 0x00FF8C28),
                    floatArrayOf(0.55f, 0.85f, 1f),
                    Shader.TileMode.CLAMP
                )
                canvas.drawCircle(cx, cy, radius, glowPaint)
            }
        }

        private fun argb(alpha: Float): Int =
            Color.argb((alpha.coerceIn(0f, 1f) * 255).toInt(), 255, 140, 40)
    }
}
